from datetime import datetime, timedelta
from sqlalchemy import select
from app import service
from app.config import IST, settings
from app.db import Audit, SessionLocal
from conftest import A1, A2, A3, A4, book, cust, staff


def test_full_withdrawal_flow_with_receipt(c):
    h, t, m = cust(c, A1), staff(c), staff(c, "manager1", "manager123")
    r = book(c, h, amt=20000); assert r.status_code == 200 and r.json()["status"] == "Confirmed"
    b = r.json()
    ci = c.post("/api/staff/checkin", headers=t, json={"token": b["token"]}); assert ci.json()["status"] == "CheckedIn"
    # withdrawal needs biometric
    assert c.post(f"/api/staff/bookings/{b['id']}/complete", headers=t, json={}).status_code == 409
    assert c.post(f"/api/staff/bookings/{b['id']}/biometric", headers=t, json={"reference": "BAD"}).status_code == 422
    assert c.post(f"/api/staff/bookings/{b['id']}/biometric", headers=t, json={"reference": "MOCK-OK"}).status_code == 200
    d = c.post(f"/api/staff/bookings/{b['id']}/complete", headers=t, json={"cbs_ref": "CBS123"}).json()
    assert d["status"] == "Done" and d["receipt"]
    assert c.get(d["receipt"]).status_code == 200
    pdf = c.get(d["receipt"] + "/pdf"); assert pdf.content[:4] == b"%PDF"
    assert any("Receipt" in x["text"] for x in c.get("/api/dev/outbox").json())
    assert c.get("/api/staff/cash", headers=t).json()["cash"] == 800000 - 20000


def test_validation_rules(c):
    h1 = cust(c, A1)
    assert book(c, h1, amt=300000).status_code == 400            # more than balance
    assert book(c, h1, typ="Deposit", amt=60000).status_code == 400  # PAN needed
    assert book(c, h1, typ="Deposit", amt=60000, pan="ZZZZZ9999Z").status_code == 400  # PAN mismatch
    assert book(c, h1, typ="Deposit", amt=60000, pan="ABCDE1234F").status_code == 200
    assert c.post("/api/otp/request", json={"account": "12"}).status_code == 400
    # frozen account never gets an OTP
    assert "dev_otp" not in c.post("/api/otp/request", json={"account": A3}).json()


def test_pending_when_cash_short_then_manager_approves(c):
    h2, t, m = cust(c, A2), staff(c), staff(c, "manager1", "manager123")
    b = book(c, h2, amt=900000).json(); assert b["status"] == "Pending"
    assert c.post(f"/api/staff/bookings/{b['id']}/approve", headers=t).status_code == 403   # teller cannot
    assert c.post(f"/api/staff/bookings/{b['id']}/approve", headers=m).status_code == 409   # no cash yet
    c.post("/api/staff/cash/add", headers=m, json={"amount": 200000})
    assert c.post(f"/api/staff/bookings/{b['id']}/approve", headers=m).json()["status"] == "Confirmed"


def test_confirmed_withdrawals_reserve_cash(c):
    h2, h4 = cust(c, A2), cust(c, A4)
    assert book(c, h2, amt=500000, slot="10:00").json()["status"] == "Confirmed"
    assert book(c, h4, amt=500000, slot="10:15").json()["status"] == "Pending"  # only 300000 left unreserved


def test_slot_capacity_and_daily_limit(c):
    assert book(c, cust(c, A1), typ="Deposit", amt=1000).status_code == 200
    assert book(c, cust(c, A2), typ="Deposit", amt=1000).status_code == 200
    assert book(c, cust(c, A4), typ="Deposit", amt=1000).status_code == 409  # slot full
    h = cust(c, A1)
    assert book(c, h, typ="Deposit", amt=1000, slot="11:00").status_code == 200
    assert book(c, h, typ="Deposit", amt=1000, slot="11:15").status_code == 409  # 3rd active booking


def test_customer_cannot_touch_others_bookings(c):
    b = book(c, cust(c, A1), amt=1000).json()
    assert c.post(f"/api/bookings/{b['id']}/cancel", headers=cust(c, A2)).status_code == 404
    assert c.get("/api/staff/bookings", headers=cust(c, A2)).status_code == 401
    assert c.post(f"/api/bookings/{b['id']}/cancel", headers=cust(c, A1)).json()["status"] == "Cancelled"


def test_otp_wrong_and_rate_limit(c):
    c.post("/api/otp/request", json={"account": A1})
    assert c.post("/api/otp/verify", json={"account": A1, "otp": "000000"}).status_code == 400
    c.post("/api/otp/request", json={"account": A1}); c.post("/api/otp/request", json={"account": A1})
    assert c.post("/api/otp/request", json={"account": A1}).status_code == 429


def test_close_day_report_and_variance(c):
    t, m = staff(c), staff(c, "manager1", "manager123")
    b = book(c, cust(c, A1), typ="Deposit", amt=5000).json()
    book(c, cust(c, A2), typ="Deposit", amt=1000, slot="11:00")  # will be a no-show
    c.post("/api/staff/checkin", headers=t, json={"token": b["token"]})
    c.post(f"/api/staff/bookings/{b['id']}/complete", headers=t, json={})
    rep = c.post("/api/staff/close-day", headers=m, json={"counted_cash": 804900}).json()
    assert rep["expected"] == 805000 and rep["variance"] == -100 and rep["counts"]["NoShow"] == 1 and rep["closed"]
    assert book(c, cust(c, A4), typ="Deposit", amt=1000).status_code == 409  # day closed
    assert c.post("/api/staff/close-day", headers=m, json={"counted_cash": 1}).status_code == 409


def test_audit_chain_is_intact(c):
    t = staff(c); b = book(c, cust(c, A1), amt=1000).json()
    c.post("/api/staff/checkin", headers=t, json={"token": b["token"]})
    with SessionLocal() as db:
        rows = db.scalars(select(Audit).order_by(Audit.id)).all()
    assert len(rows) >= 2 and all(rows[i].prev_hash == rows[i - 1].hash for i in range(1, len(rows)))


def test_checkin_window_when_time_enforced(c, monkeypatch):
    settings.ENFORCE_TIME = True
    fixed = {"t": datetime.now(IST).replace(hour=9, minute=0, second=0, microsecond=0)}
    monkeypatch.setattr(service, "now", lambda: fixed["t"])
    t = staff(c); b = book(c, cust(c, A1), amt=1000, slot="10:00").json()
    assert c.post("/api/staff/checkin", headers=t, json={"token": b["token"]}).status_code == 409  # too early
    fixed["t"] = fixed["t"].replace(hour=9, minute=45)
    assert c.post("/api/staff/checkin", headers=t, json={"token": b["token"]}).status_code == 200
    assert book(c, cust(c, A2), amt=1000, slot="09:45").status_code == 400  # not an offered slot
