import os, pathlib
os.environ.update(DB_URL="sqlite:///./test_cashslot.db", DEV_MODE="1", ENFORCE_TIME="0")
pathlib.Path("test_cashslot.db").unlink(missing_ok=True)
import pytest
from fastapi.testclient import TestClient
from app import adapters, security, service
from app.db import Base, engine
from app.main import app
from app.config import settings

A1, A2, A3, A4 = "100000000001", "100000000002", "100000000003", "100000000004"


@pytest.fixture(autouse=True)
def fresh():
    Base.metadata.drop_all(engine); Base.metadata.create_all(engine)
    security.FAILS.clear(); settings.ENFORCE_TIME = False
    adapters._inst = None
    yield


@pytest.fixture
def c(): return TestClient(app)


def cust(c, acc):
    otp = c.post("/api/otp/request", json={"account": acc}).json()["dev_otp"]
    t = c.post("/api/otp/verify", json={"account": acc, "otp": otp}).json()["token"]
    return {"Authorization": "Bearer " + t}


def staff(c, user="teller1", pw="teller123"):
    return {"Authorization": "Bearer " + c.post("/api/staff/login", json={"username": user, "password": pw}).json()["token"]}


def book(c, h, typ="Withdrawal", amt=10000, slot="10:00", pan=None, date=None):
    return c.post("/api/bookings", headers=h, json={"branch": "BR001", "date": date or service.today(), "slot": slot, "type": typ, "amount": amt, "pan": pan})
