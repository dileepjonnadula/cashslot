import json, httpx, pytest
from app.adapters import CBSError
from app.adapters.rest import RestAdapter


def _adapter(tmp_path, monkeypatch, handler):
    p = tmp_path / "c.json"; p.write_text(open("config/cbs_rest.example.json").read())
    monkeypatch.setenv("CBS_TOKEN", "t")
    monkeypatch.setattr(httpx, "request", lambda m, u, **kw: handler(m, u, kw))
    return RestAdapter(str(p))


def test_maps_fields(tmp_path, monkeypatch):
    body = {"data": {"customerName": "A B", "accountStatus": "ACTIVE", "availableBalance": "1500.75", "registeredMobile": "9000000000", "pan": "ABCDE1234F", "kycStatus": "COMPLETE"}}
    acc = _adapter(tmp_path, monkeypatch, lambda m, u, kw: httpx.Response(200, json=body)).get_account("123456789012")
    assert (acc.name, acc.status, acc.balance, acc.kyc_ok) == ("A B", "Active", 1500, True)


def test_not_found_and_errors(tmp_path, monkeypatch):
    assert _adapter(tmp_path, monkeypatch, lambda m, u, kw: httpx.Response(404)).get_account("123456789012") is None
    with pytest.raises(CBSError): _adapter(tmp_path, monkeypatch, lambda m, u, kw: httpx.Response(500)).get_account("123456789012")
    def boom(m, u, kw): raise httpx.ConnectError("down")
    with pytest.raises(CBSError): _adapter(tmp_path, monkeypatch, boom).get_account("123456789012")
