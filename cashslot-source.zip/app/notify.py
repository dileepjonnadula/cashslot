import logging
from abc import ABC, abstractmethod

import httpx

from .config import settings
from .util import load

log = logging.getLogger("cashslot.notify")


class Notifier(ABC):
    @abstractmethod
    def send(self, mobile: str, text: str, event: str = "") -> None: ...


class LogNotifier(Notifier):
    def __init__(self):
        self.outbox = []

    def send(self, mobile, text, event=""):
        self.outbox = (self.outbox + [{"to": "******" + mobile[-4:], "text": text, "event": event}])[-50:]
        log.info("SMS to ******%s: %s", mobile[-4:], text)


class WebhookNotifier(Notifier):
    """POSTs {mobile, text, event} so the bank's own SMS/WhatsApp gateway can deliver it."""
    def send(self, mobile, text, event=""):
        try:
            httpx.post(settings.NOTIFY_WEBHOOK_URL, json={"mobile": mobile, "text": text, "event": event}, timeout=5)
        except httpx.HTTPError as e:
            log.warning("notify failed: %s", e)


_inst = None


def get_notifier() -> Notifier:
    global _inst
    if _inst is None:
        n = settings.NOTIFIER
        _inst = LogNotifier() if n == "log" else WebhookNotifier() if n == "webhook" else load(n)()
    return _inst
