import importlib


def load(spec: str):
    """Load 'package.module:ClassName' so banks can plug in their own classes."""
    mod, cls = spec.split(":")
    return getattr(importlib.import_module(mod), cls)
