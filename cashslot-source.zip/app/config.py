"""All settings come from environment variables (see .env.example)."""
import os
from datetime import timedelta, timezone

IST = timezone(timedelta(hours=5, minutes=30))
_e = lambda k, d: os.getenv(k, d)
_b = lambda k, d: _e(k, d) in ("1", "true", "True", "yes")


class Settings:
    def __init__(self):
        self.BANK_NAME = _e("BANK_NAME", "Demo Bank")
        self.PUBLIC_BASE_URL = _e("PUBLIC_BASE_URL", "http://localhost:8000")
        self.DB_URL = _e("DB_URL", "sqlite:///./cashslot.db")
        self.SECRET = _e("SECRET", "dev-secret-change-me")
        self.ALLOWED_ORIGINS = _e("ALLOWED_ORIGINS", "*").split(",")
        self.DEV_MODE = _b("DEV_MODE", "1")  # returns OTP in API + exposes SMS outbox. MUST be 0 in production.
        # plug-in points: "mock" | "rest" | "package.module:ClassName"
        self.CBS_ADAPTER = _e("CBS_ADAPTER", "mock")
        self.CBS_REST_CONFIG = _e("CBS_REST_CONFIG", "config/cbs_rest.example.json")
        self.BIO_PROVIDER = _e("BIO_PROVIDER", "mock")
        self.NOTIFIER = _e("NOTIFIER", "log")  # log | webhook | package.module:ClassName
        self.NOTIFY_WEBHOOK_URL = _e("NOTIFY_WEBHOOK_URL", "")
        self.ALERT_MOBILE = _e("ALERT_MOBILE", "")  # manager number for large-transaction alerts
        # branches "CODE:Name,CODE:Name"
        self.BRANCHES = dict(x.split(":", 1) for x in _e("BRANCHES", "BR001:Main Branch,BR002:Market Road Branch").split(","))
        # staff "user:password:role:branch" (role = teller|manager). Replace with bank SSO in production.
        self.STAFF_USERS = _e("STAFF_USERS", "teller1:teller123:teller:BR001,manager1:manager123:manager:BR001")
        self.OPEN_HOUR, self.CLOSE_HOUR = int(_e("OPEN_HOUR", "10")), int(_e("CLOSE_HOUR", "15"))
        self.SLOT_MINUTES, self.SLOT_CAPACITY = int(_e("SLOT_MINUTES", "15")), int(_e("SLOT_CAPACITY", "2"))
        self.MAX_DAYS_AHEAD, self.MAX_ACTIVE_PER_DAY = int(_e("MAX_DAYS_AHEAD", "3")), int(_e("MAX_ACTIVE_PER_DAY", "2"))
        self.ENFORCE_TIME = _b("ENFORCE_TIME", "0")  # 1 = block past slots, enforce check-in window
        self.CHECKIN_EARLY_MIN, self.CHECKIN_GRACE_MIN = int(_e("CHECKIN_EARLY_MIN", "30")), int(_e("CHECKIN_GRACE_MIN", "30"))
        self.INITIAL_CASH = int(_e("INITIAL_CASH", "800000"))
        self.MIN_AMOUNT = int(_e("MIN_AMOUNT", "100"))
        # Compliance thresholds: confirm with your compliance team.
        self.PAN_DEPOSIT_ABOVE = int(_e("PAN_DEPOSIT_ABOVE", "50000"))
        self.PAN_WITHDRAW_ATLEAST = int(_e("PAN_WITHDRAW_ATLEAST", "2000000"))
        self.LARGE_TXN = int(_e("LARGE_TXN", "1000000"))
        self.LARGE_NEEDS_APPROVAL = _b("LARGE_NEEDS_APPROVAL", "0")
        self.BIO_REQUIRED_FOR = _e("BIO_REQUIRED_FOR", "Withdrawal").split(",")
        self.REQUIRE_CBS_REF = _b("REQUIRE_CBS_REF", "0")
        self.OTP_TTL, self.OTP_MAX_TRIES = 300, 5


settings = Settings()
