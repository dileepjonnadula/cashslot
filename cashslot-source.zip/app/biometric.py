"""The plug-in never sees raw biometric data. The teller's device talks to the bank's authorised
biometric service (AUA/KUA or bank-owned) and passes only a reference/result token here."""
import secrets
from abc import ABC, abstractmethod

from .config import settings
from .util import load


class BiometricProvider(ABC):
    @abstractmethod
    def verify(self, acc_no: str, reference: str) -> str | None:
        """Return a verification reference if matched, else None."""


class MockBiometric(BiometricProvider):
    def verify(self, acc_no, reference):
        return "BIO-" + secrets.token_hex(4) if reference.startswith("MOCK-OK") else None


_inst = None


def get_biometric() -> BiometricProvider:
    global _inst
    if _inst is None:
        _inst = MockBiometric() if settings.BIO_PROVIDER == "mock" else load(settings.BIO_PROVIDER)()
    return _inst
