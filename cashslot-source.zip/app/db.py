from sqlalchemy import BigInteger, Boolean, Float, Integer, String, Text, UniqueConstraint, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from .config import settings


class Base(DeclarativeBase):
    pass


class Booking(Base):
    __tablename__ = "bookings"
    __table_args__ = (UniqueConstraint("branch", "date", "token"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token: Mapped[str] = mapped_column(String(16))
    branch: Mapped[str] = mapped_column(String(10), index=True)
    date: Mapped[str] = mapped_column(String(10), index=True)
    slot: Mapped[str] = mapped_column(String(5))
    acc_no: Mapped[str] = mapped_column(String(20), index=True)
    name: Mapped[str] = mapped_column(String(120))
    type: Mapped[str] = mapped_column(String(12))
    amount: Mapped[int] = mapped_column(BigInteger)  # whole rupees
    status: Mapped[str] = mapped_column(String(12))  # Pending Confirmed CheckedIn Done Rejected Cancelled NoShow
    large: Mapped[bool] = mapped_column(Boolean, default=False)
    pan_masked: Mapped[str | None] = mapped_column(String(10), nullable=True)
    bio_ref: Mapped[str | None] = mapped_column(String(60), nullable=True)
    cbs_ref: Mapped[str | None] = mapped_column(String(60), nullable=True)
    receipt_ref: Mapped[str | None] = mapped_column(String(40), nullable=True, unique=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[str] = mapped_column(String(30))
    updated_at: Mapped[str] = mapped_column(String(30))


class Branch(Base):
    __tablename__ = "branches"
    code: Mapped[str] = mapped_column(String(10), primary_key=True)
    cash: Mapped[int] = mapped_column(BigInteger)
    day: Mapped[str] = mapped_column(String(10))
    opening: Mapped[int] = mapped_column(BigInteger)
    received: Mapped[int] = mapped_column(BigInteger, default=0)


class DayClose(Base):
    __tablename__ = "day_close"
    __table_args__ = (UniqueConstraint("branch", "date"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    branch: Mapped[str] = mapped_column(String(10))
    date: Mapped[str] = mapped_column(String(10))
    opening: Mapped[int] = mapped_column(BigInteger)
    received: Mapped[int] = mapped_column(BigInteger)
    deposits: Mapped[int] = mapped_column(BigInteger)
    withdrawals: Mapped[int] = mapped_column(BigInteger)
    expected: Mapped[int] = mapped_column(BigInteger)
    counted: Mapped[int] = mapped_column(BigInteger)
    variance: Mapped[int] = mapped_column(BigInteger)
    closed_by: Mapped[str] = mapped_column(String(60))
    closed_at: Mapped[str] = mapped_column(String(30))


class Audit(Base):  # append-only, hash-chained
    __tablename__ = "audit"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ts: Mapped[str] = mapped_column(String(30))
    actor: Mapped[str] = mapped_column(String(60))
    action: Mapped[str] = mapped_column(String(40))
    ref: Mapped[str] = mapped_column(String(60))
    detail: Mapped[str] = mapped_column(Text)
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64))


class Otp(Base):
    __tablename__ = "otps"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    acc_no: Mapped[str] = mapped_column(String(20), index=True)
    code_hash: Mapped[str] = mapped_column(String(64))
    expires: Mapped[float] = mapped_column(Float)
    created: Mapped[float] = mapped_column(Float)
    tries: Mapped[int] = mapped_column(Integer, default=0)


_args = {"check_same_thread": False} if settings.DB_URL.startswith("sqlite") else {}
engine = create_engine(settings.DB_URL, connect_args=_args, pool_pre_ping=True)
SessionLocal = sessionmaker(engine, expire_on_commit=False)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
