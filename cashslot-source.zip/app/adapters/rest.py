"""Config-driven REST adapter. Point it at any CBS gateway that can return account info as JSON.
See config/cbs_rest.example.json and README for the field mapping."""
import json, os
import httpx

from . import Account, CBSAdapter, CBSError


def dig(o, path):
    for k in path.split("."):
        try:
            o = o[int(k)] if isinstance(o, list) else o[k]
        except (KeyError, IndexError, TypeError, ValueError):
            return None
    return o


class RestAdapter(CBSAdapter):
    def __init__(self, cfg_path):
        self.c = json.load(open(cfg_path))

    def _headers(self):
        h, a = dict(self.c.get("headers", {})), self.c.get("auth", {})
        if a.get("type") == "bearer":
            h["Authorization"] = "Bearer " + os.environ[a["token_env"]]
        elif a.get("type") == "header":
            h[a["name"]] = os.environ[a["value_env"]]
        return h

    def get_account(self, acc_no):
        req = self.c["account_lookup"]
        body = json.loads(json.dumps(req["body"]).replace("{acc_no}", acc_no)) if req.get("body") else None
        try:
            r = httpx.request(req.get("method", "GET"), self.c["base_url"].rstrip("/") + req["path"].format(acc_no=acc_no),
                              headers=self._headers(), json=body, timeout=self.c.get("timeout", 5), verify=self.c.get("verify_tls", True))
        except httpx.HTTPError as e:
            raise CBSError(f"CBS unreachable: {e}")
        if r.status_code in self.c.get("not_found_http", [404]):
            return None
        if r.status_code >= 400:
            raise CBSError(f"CBS returned HTTP {r.status_code}")
        d, m = r.json(), self.c["map"]
        bal = dig(d, m["balance"])
        if bal is None:
            raise CBSError("CBS response has no balance field")
        status = "Active" if str(dig(d, m["status"])) in self.c.get("active_values", ["ACTIVE"]) else str(dig(d, m["status"]))
        kyc_ok = True if "kyc" not in m else str(dig(d, m["kyc"])) in self.c.get("kyc_ok_values", ["true", "True", "Y", "COMPLETE"])
        return Account(acc_no, dig(d, m["name"]) or "", status, int(float(bal) * self.c.get("balance_scale", 1)),
                       str(dig(d, m["mobile"]) or ""), dig(d, m["pan"]) if "pan" in m else None, kyc_ok)
