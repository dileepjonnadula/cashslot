from . import Account, CBSAdapter


class MockAdapter(CBSAdapter):
    def __init__(self):
        self.accounts = {a.acc_no: a for a in [
            Account("100000000001", "Ravi Kumar", "Active", 250000, "9800000001", "ABCDE1234F"),
            Account("100000000002", "Lakshmi Devi", "Active", 1200000, "9800000002", "PQRSX5678L"),
            Account("100000000003", "Suresh Babu", "Frozen", 80000, "9800000003"),
            Account("100000000004", "Anita Rao", "Active", 5000000, "9800000004", "LMNOP4321Q"),
        ]}

    def get_account(self, acc_no):
        return self.accounts.get(acc_no)
