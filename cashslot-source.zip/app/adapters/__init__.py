"""CBS adapter contract. A bank/vendor implements ONE method: get_account()."""
from abc import ABC, abstractmethod
from dataclasses import dataclass

from ..config import settings
from ..util import load


class CBSError(Exception):
    """CBS unreachable or returned an unusable answer."""


@dataclass
class Account:
    acc_no: str
    name: str
    status: str  # "Active" or anything else (Frozen, Dormant, Closed ...)
    balance: int  # available balance, whole rupees
    mobile: str  # registered mobile
    pan: str | None = None
    kyc_ok: bool = True


class CBSAdapter(ABC):
    @abstractmethod
    def get_account(self, acc_no: str) -> "Account | None":
        """Return None if the account does not exist; raise CBSError if the CBS cannot answer."""


_inst = None


def get_adapter() -> CBSAdapter:
    global _inst
    if _inst is None:
        s = settings.CBS_ADAPTER
        if s == "mock":
            from .mock import MockAdapter
            _inst = MockAdapter()
        elif s == "rest":
            from .rest import RestAdapter
            _inst = RestAdapter(settings.CBS_REST_CONFIG)
        else:
            _inst = load(s)()
    return _inst
