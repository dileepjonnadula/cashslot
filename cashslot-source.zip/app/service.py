"""Business rules. Everything the bank cares about lives here."""
import hashlib, hmac, io, re, secrets, threading, time, zlib
from datetime import datetime, timedelta

from sqlalchemy import func, select, text

from . import security
from .adapters import CBSError, get_adapter
from .biometric import get_biometric
from .config import IST, settings
from .db import Audit, Booking, Branch, DayClose, Otp
from .errors import ApiError
from .notify import get_notifier

LOCK = threading.Lock()
ACTIVE = ("Pending", "Confirmed", "CheckedIn")
COUNTED = ACTIVE + ("Done",)
ACC_RE, PAN_RE = re.compile(r"^\d{9,18}$"), re.compile(r"^[A-Z]{5}[0-9]{4}[A-Z]$")


def now(): return datetime.now(IST)
def today(): return now().date().isoformat()
def stamp(): return now().isoformat(timespec="seconds")
def mask_acc(a): return "XXXXXX" + a[-4:]
def inr(n): return "₹" + f"{n:,}"


def audit(db, actor, action, ref="", detail=""):
    last = db.execute(select(Audit).order_by(Audit.id.desc()).limit(1)).scalar_one_or_none()
    prev, ts = (last.hash if last else "0" * 64), stamp()
    h = hashlib.sha256(f"{prev}|{ts}|{actor}|{action}|{ref}|{detail}".encode()).hexdigest()
    db.add(Audit(ts=ts, actor=actor, action=action, ref=ref, detail=detail, prev_hash=prev, hash=h))


def cbs_account(acc_no):
    if not ACC_RE.match(acc_no or ""):
        raise ApiError(400, "Enter a valid account number (9 to 18 digits).")
    try:
        return get_adapter().get_account(acc_no)
    except CBSError:
        raise ApiError(503, "We can’t reach the bank system right now. Please try again shortly.")


def notify_customer(b, msg):
    try:
        a = get_adapter().get_account(b.acc_no)
        if a and a.mobile:
            get_notifier().send(a.mobile, msg, "booking")
    except Exception:
        pass


# ---------- customer login (OTP to the CBS-registered mobile) ----------
def request_otp(db, acc_no):
    acc = cbs_account(acc_no)
    recent = db.scalar(select(func.count()).select_from(Otp).where(Otp.acc_no == acc_no, Otp.created > time.time() - 600))
    if recent >= 3:
        raise ApiError(429, "Too many OTP requests. Try again in 10 minutes.")
    resp = {"message": "If this account can book, an OTP was sent to the registered mobile number."}
    code, ok = f"{secrets.randbelow(10**6):06d}", bool(acc and acc.status == "Active")
    db.add(Otp(acc_no=acc_no, code_hash=security.hash_otp(acc_no, code) if ok else "", expires=time.time() + settings.OTP_TTL, created=time.time(), tries=0))
    db.commit()
    if ok:
        get_notifier().send(acc.mobile, f"{code} is your {settings.BANK_NAME} Cash Slot OTP. Valid 5 minutes. Do not share it.", "otp")
        if settings.DEV_MODE:
            resp["dev_otp"] = code
    return resp


def verify_otp(db, acc_no, code):
    o = db.scalars(select(Otp).where(Otp.acc_no == acc_no, Otp.code_hash != "", Otp.expires > time.time()).order_by(Otp.id.desc())).first()
    if not o or o.tries >= settings.OTP_MAX_TRIES:
        raise ApiError(400, "OTP expired or not found. Request a new one.")
    o.tries += 1
    if not hmac.compare_digest(o.code_hash, security.hash_otp(acc_no, code or "")):
        db.commit()
        raise ApiError(400, "Wrong OTP.")
    o.expires = 0
    db.commit()
    acc = cbs_account(acc_no)
    return {"token": security.sign({"k": "c", "acc": acc_no}, 1800), "name": acc.name}


# ---------- slots & cash ----------
def all_slots():
    out, t = [], settings.OPEN_HOUR * 60
    while t < settings.CLOSE_HOUR * 60:
        out.append(f"{t // 60:02d}:{t % 60:02d}")
        t += settings.SLOT_MINUTES
    return out


def slot_dt(date, slot): return datetime.fromisoformat(f"{date}T{slot}:00").replace(tzinfo=IST)


def check_date(date):
    try:
        d = datetime.fromisoformat(date).date()
    except Exception:
        raise ApiError(400, "Choose a valid date.")
    t = now().date()
    if d < t or d > t + timedelta(days=settings.MAX_DAYS_AHEAD):
        raise ApiError(400, f"You can book from today up to {settings.MAX_DAYS_AHEAD} days ahead.")


def get_branch(db, code):
    if code not in settings.BRANCHES:
        raise ApiError(404, "Branch not found.")
    b = db.get(Branch, code)
    if not b:
        b = Branch(code=code, cash=settings.INITIAL_CASH, opening=settings.INITIAL_CASH, received=0, day=today())
        db.add(b)
        db.flush()
    if b.day != today():  # new business day: yesterday's closing is today's opening
        b.day, b.opening, b.received = today(), b.cash, 0
    return b


def committed(db, branch, date):
    return db.scalar(select(func.coalesce(func.sum(Booking.amount), 0)).where(
        Booking.branch == branch, Booking.date == date, Booking.type == "Withdrawal", Booking.status.in_(("Confirmed", "CheckedIn"))))


def available(db, branch, date):
    return get_branch(db, branch).cash - committed(db, branch, date)


def is_closed(db, branch, date):
    return db.scalar(select(DayClose.id).where(DayClose.branch == branch, DayClose.date == date)) is not None


def slots_view(db, branch, date):
    get_branch(db, branch); check_date(date)
    out = []
    for s in all_slots():
        used = db.scalar(select(func.count()).select_from(Booking).where(Booking.branch == branch, Booking.date == date, Booking.slot == s, Booking.status.in_(COUNTED)))
        past = settings.ENFORCE_TIME and slot_dt(date, s) < now() + timedelta(minutes=10)
        out.append({"slot": s, "free": max(0, settings.SLOT_CAPACITY - used), "available": used < settings.SLOT_CAPACITY and not past})
    return out


# ---------- booking ----------
def view(b, staff=False):
    d = dict(id=b.id, token=b.token, branch=b.branch, date=b.date, slot=b.slot, type=b.type, amount=b.amount, status=b.status,
             large=b.large, account=mask_acc(b.acc_no), note=b.note, receipt=f"/r/{b.receipt_ref}" if b.receipt_ref else None)
    if staff:
        d.update(name=b.name, bio=bool(b.bio_ref), cbs_ref=b.cbs_ref)
    return d


def create_booking(db, acc_no, branch, date, slot, typ, amount, pan):
    get_branch(db, branch); check_date(date)
    if slot not in all_slots(): raise ApiError(400, "Choose a valid slot.")
    if settings.ENFORCE_TIME and slot_dt(date, slot) < now() + timedelta(minutes=10):
        raise ApiError(400, "That slot has already started. Choose a later slot.")
    if typ not in ("Deposit", "Withdrawal"): raise ApiError(400, "Choose deposit or withdrawal.")
    if amount < settings.MIN_AMOUNT: raise ApiError(400, f"Minimum amount is {inr(settings.MIN_AMOUNT)}.")
    if is_closed(db, branch, date): raise ApiError(409, "This day is closed for bookings.")
    acc = cbs_account(acc_no)
    if not acc: raise ApiError(404, "Account not found.")
    if acc.status != "Active": raise ApiError(403, f"This account is {acc.status.lower()}. Please contact your branch.")
    if not acc.kyc_ok: raise ApiError(403, "KYC update is pending. Please visit the branch.")
    if typ == "Withdrawal" and amount > acc.balance: raise ApiError(400, "Amount is more than your available balance.")
    pan = (pan or "").strip().upper()
    need_pan = (typ == "Deposit" and amount > settings.PAN_DEPOSIT_ABOVE) or (typ == "Withdrawal" and amount >= settings.PAN_WITHDRAW_ATLEAST)
    if pan and not PAN_RE.match(pan): raise ApiError(400, "PAN format looks wrong. Example: ABCDE1234F.")
    if need_pan and not pan: raise ApiError(400, "PAN is required for this amount.")
    if pan and acc.pan and pan != acc.pan.upper(): raise ApiError(400, "PAN does not match the bank’s records.")
    with LOCK:
        if db.bind.dialect.name == "postgresql":  # cross-instance safety
            db.execute(text("select pg_advisory_xact_lock(:k)"), {"k": zlib.crc32(f"{branch}{date}{slot}".encode())})
        if db.scalar(select(func.count()).select_from(Booking).where(Booking.acc_no == acc_no, Booking.date == date, Booking.status.in_(ACTIVE))) >= settings.MAX_ACTIVE_PER_DAY:
            raise ApiError(409, f"You already have {settings.MAX_ACTIVE_PER_DAY} active bookings for this date.")
        if db.scalar(select(func.count()).select_from(Booking).where(Booking.branch == branch, Booking.date == date, Booking.slot == slot, Booking.status.in_(COUNTED))) >= settings.SLOT_CAPACITY:
            raise ApiError(409, "That slot is full. Please pick another.")
        large = amount >= settings.LARGE_TXN
        hold = (typ == "Withdrawal" and amount > available(db, branch, date)) or (large and settings.LARGE_NEEDS_APPROVAL)
        n = db.scalar(select(func.count()).select_from(Booking).where(Booking.branch == branch, Booking.date == date)) + 1
        b = Booking(token=f"{'W' if typ == 'Withdrawal' else 'D'}-{n:03d}", branch=branch, date=date, slot=slot, acc_no=acc_no, name=acc.name,
                    type=typ, amount=amount, status="Pending" if hold else "Confirmed", large=large,
                    pan_masked=(pan[:2] + "XXXXX" + pan[-3:]) if pan else None, created_at=stamp(), updated_at=stamp())
        db.add(b)
        audit(db, "customer:" + mask_acc(acc_no), "BOOK", b.token, f"{typ} {amount} {date} {slot} {b.status}")
        db.commit()
    if b.status == "Pending":
        get_notifier().send(acc.mobile, f"{settings.BANK_NAME}: token {b.token} requested for {date} {slot}. Waiting for branch cash approval; we will message you.", "pending")
    else:
        get_notifier().send(acc.mobile, f"{settings.BANK_NAME}: token {b.token} confirmed for {date} {slot} ({typ} {inr(amount)}). Please arrive 5 minutes early with your ID.", "confirmed")
    if large and settings.ALERT_MOBILE:
        get_notifier().send(settings.ALERT_MOBILE, f"Large {typ.lower()} {inr(amount)} booked at {branch} for {date} {slot}.", "alert")
    return b


def my_bookings(db, acc_no):
    rows = db.scalars(select(Booking).where(Booking.acc_no == acc_no, Booking.date >= today()).order_by(Booking.date, Booking.slot)).all()
    return [view(b) for b in rows]


def cancel(db, acc_no, bid):
    b = db.get(Booking, bid)
    if not b or b.acc_no != acc_no: raise ApiError(404, "Booking not found.")
    if b.status not in ("Pending", "Confirmed"): raise ApiError(409, "This booking can no longer be cancelled.")
    b.status, b.updated_at = "Cancelled", stamp()
    audit(db, "customer:" + mask_acc(acc_no), "CANCEL", b.token)
    db.commit()
    return view(b)


# ---------- staff ----------
def _get(db, bid, branch):
    b = db.get(Booking, bid)
    if not b or b.branch != branch: raise ApiError(404, "Booking not found.")
    return b


def list_bookings(db, branch, date):
    rows = db.scalars(select(Booking).where(Booking.branch == branch, Booking.date == date).order_by(Booking.slot, Booking.id)).all()
    return [view(b, True) for b in rows]


def cash_status(db, branch, date):
    b = get_branch(db, branch); db.commit()
    return {"cash": b.cash, "committed": committed(db, branch, date), "available": available(db, branch, date), "opening": b.opening, "received": b.received}


def add_cash(db, branch, amount, user):
    b = get_branch(db, branch)
    b.cash += amount; b.received += amount
    audit(db, user, "CASH_ADD", branch, str(amount))
    db.commit()
    return cash_status(db, branch, today())


def approve(db, bid, branch, user):
    b = _get(db, bid, branch)
    if b.status != "Pending": raise ApiError(409, "Only pending bookings can be approved.")
    if is_closed(db, branch, b.date): raise ApiError(409, "That day is closed.")
    acc = cbs_account(b.acc_no)
    if not acc or acc.status != "Active": raise ApiError(409, "Account is no longer active.")
    if b.type == "Withdrawal":
        if b.amount > acc.balance: raise ApiError(409, "Customer balance is now lower than the amount.")
        if b.amount > available(db, branch, b.date): raise ApiError(409, "Not enough cash for that date yet. Add cash first.")
    b.status, b.updated_at = "Confirmed", stamp()
    audit(db, user, "APPROVE", b.token)
    db.commit()
    notify_customer(b, f"{settings.BANK_NAME}: token {b.token} is confirmed for {b.date} {b.slot}. Please arrive 5 minutes early.")
    return view(b, True)


def reject(db, bid, branch, user, reason):
    b = _get(db, bid, branch)
    if b.status not in ("Pending", "Confirmed"): raise ApiError(409, "This booking cannot be rejected now.")
    b.status, b.note, b.updated_at = "Rejected", reason[:200] or None, stamp()
    audit(db, user, "REJECT", b.token, reason[:200])
    db.commit()
    notify_customer(b, f"{settings.BANK_NAME}: token {b.token} could not be confirmed. Please rebook or contact the branch.")
    return view(b, True)


def checkin(db, branch, token, date, user):
    date = date or today()
    b = db.scalars(select(Booking).where(Booking.branch == branch, Booking.date == date, Booking.token == token.strip().upper())).first()
    if not b: raise ApiError(404, "Token not found for that date.")
    if b.status != "Confirmed": raise ApiError(409, f"Token is {b.status}; only confirmed tokens can check in.")
    if settings.ENFORCE_TIME:
        s = slot_dt(b.date, b.slot)
        if now() < s - timedelta(minutes=settings.CHECKIN_EARLY_MIN): raise ApiError(409, "Too early. Check-in opens 30 minutes before the slot.")
        if now() > s + timedelta(minutes=settings.CHECKIN_GRACE_MIN): raise ApiError(409, "Slot time has passed. Please rebook.")
    b.status, b.updated_at = "CheckedIn", stamp()
    audit(db, user, "CHECKIN", b.token)
    db.commit()
    return view(b, True)


def biometric(db, bid, branch, reference, user):
    b = _get(db, bid, branch)
    if b.status != "CheckedIn": raise ApiError(409, "Check the customer in first.")
    ref = get_biometric().verify(b.acc_no, reference)
    if not ref:
        audit(db, user, "BIO_FAIL", b.token); db.commit()
        raise ApiError(422, "Fingerprint did not match. Try again or use signature verification.")
    b.bio_ref, b.updated_at = ref, stamp()
    audit(db, user, "BIO_OK", b.token, ref)
    db.commit()
    return view(b, True)


def complete(db, bid, branch, cbs_ref, user):
    b = _get(db, bid, branch)
    if b.status != "CheckedIn": raise ApiError(409, "Customer is not checked in.")
    if b.type in settings.BIO_REQUIRED_FOR and not b.bio_ref: raise ApiError(409, "Biometric verification is required first.")
    if settings.REQUIRE_CBS_REF and not cbs_ref: raise ApiError(400, "Enter the CBS transaction reference.")
    if is_closed(db, branch, b.date): raise ApiError(409, "That day is closed.")
    acc = cbs_account(b.acc_no)  # re-validate at the counter, not only at booking
    if not acc or acc.status != "Active": raise ApiError(409, "Account is no longer active.")
    br = get_branch(db, branch)
    if b.type == "Withdrawal":
        if b.amount > acc.balance: raise ApiError(409, "Balance is now lower than the withdrawal amount.")
        if b.amount > br.cash: raise ApiError(409, "Not enough cash at the counter.")
        br.cash -= b.amount
    else:
        br.cash += b.amount
    b.status, b.cbs_ref, b.receipt_ref, b.updated_at = "Done", (cbs_ref or None), secrets.token_urlsafe(12), stamp()
    audit(db, user, "COMPLETE", b.token, f"{b.type} {b.amount} cbs={cbs_ref or '-'}")
    db.commit()
    notify_customer(b, f"{settings.BANK_NAME}: your {b.type.lower()} of {inr(b.amount)} is complete. Receipt: {settings.PUBLIC_BASE_URL}/r/{b.receipt_ref}")
    return view(b, True)


def _totals(rows):
    done = [b for b in rows if b.status == "Done"]
    return sum(b.amount for b in done if b.type == "Deposit"), sum(b.amount for b in done if b.type == "Withdrawal")


def report(db, branch, date):
    rows = db.scalars(select(Booking).where(Booking.branch == branch, Booking.date == date).order_by(Booking.slot)).all()
    dep, wd = _totals(rows)
    counts = {}
    for b in rows: counts[b.status] = counts.get(b.status, 0) + 1
    dc = db.scalars(select(DayClose).where(DayClose.branch == branch, DayClose.date == date)).first()
    r = {"date": date, "branch": branch, "issued": len(rows), "counts": counts, "deposits": dep, "withdrawals": wd,
         "large": [view(b, True) for b in rows if b.large and b.status == "Done"], "closed": bool(dc),
         "opening": None, "received": None, "expected": None, "counted": None, "variance": None}
    if dc:
        r.update(opening=dc.opening, received=dc.received, expected=dc.expected, counted=dc.counted, variance=dc.variance, closed_by=dc.closed_by)
    elif date == today():
        br = get_branch(db, branch); db.commit()
        r.update(opening=br.opening, received=br.received, expected=br.opening + br.received + dep - wd)
    return r


def close_day(db, branch, counted, user):
    date = today()
    if is_closed(db, branch, date): raise ApiError(409, "Today is already closed.")
    rows = db.scalars(select(Booking).where(Booking.branch == branch, Booking.date == date)).all()
    for b in rows:
        if b.status in ACTIVE: b.status, b.updated_at = "NoShow", stamp()
    dep, wd = _totals(rows)
    br = get_branch(db, branch)
    exp = br.opening + br.received + dep - wd
    db.add(DayClose(branch=branch, date=date, opening=br.opening, received=br.received, deposits=dep, withdrawals=wd, expected=exp,
                    counted=counted, variance=counted - exp, closed_by=user, closed_at=stamp()))
    audit(db, user, "CLOSE_DAY", branch, f"expected={exp} counted={counted} variance={counted - exp}")
    db.commit()
    return report(db, branch, date)


# ---------- receipts ----------
def receipt_data(db, ref):
    b = db.scalars(select(Booking).where(Booking.receipt_ref == ref, Booking.status == "Done")).first()
    if not b: raise ApiError(404, "Receipt not found.")
    return {"rref": ref, "bank": settings.BANK_NAME, "branch": settings.BRANCHES.get(b.branch, b.branch), "ref": f"{b.branch}-{b.date.replace('-', '')}-{b.token}",
            "when": b.updated_at, "name": b.name, "account": mask_acc(b.acc_no), "type": b.type, "amount": b.amount, "token": b.token,
            "cbs_ref": b.cbs_ref or "-", "bio": "Yes" if b.bio_ref else "No"}


def receipt_html(d):
    rows = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in [
        ("Reference", d["ref"]), ("Date and time", d["when"]), ("Branch", d["branch"]), ("Customer", d["name"]), ("Account", d["account"]),
        ("Transaction", d["type"]), ("Amount", inr(d["amount"])), ("Token", d["token"]), ("CBS reference", d["cbs_ref"]), ("Biometric verified", d["bio"])])
    return (f"<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>Receipt {d['ref']}</title>"
            "<style>body{font:15px system-ui;max-width:460px;margin:24px auto;padding:0 14px}td{padding:6px 4px;border-bottom:1px solid #ccc}td:first-child{color:#555}</style>"
            f"<h2>{d['bank']}</h2><p>Cash transaction receipt</p><table>{rows}</table><p><a href='/r/{d['rref']}/pdf'>Download PDF</a></p>")


def receipt_pdf(d) -> bytes:
    from reportlab.lib.pagesizes import A5
    from reportlab.pdfgen import canvas
    buf = io.BytesIO(); c = canvas.Canvas(buf, pagesize=A5); y = 380
    c.setFont("Helvetica-Bold", 15); c.drawString(40, y, d["bank"]); y -= 20
    c.setFont("Helvetica", 11); c.drawString(40, y, "Cash transaction receipt"); y -= 30
    for k, v in [("Reference", d["ref"]), ("Date and time", d["when"]), ("Branch", d["branch"]), ("Customer", d["name"]), ("Account", d["account"]),
                 ("Transaction", d["type"]), ("Amount", f"Rs. {d['amount']:,}"), ("Token", d["token"]), ("CBS reference", d["cbs_ref"]), ("Biometric verified", d["bio"])]:
        c.drawString(40, y, k); c.drawString(170, y, str(v)); y -= 22
    c.showPage(); c.save()
    return buf.getvalue()
