import base64, hashlib, hmac, json, time
from fastapi import Header

from .config import settings
from .errors import ApiError

_b = lambda x: base64.urlsafe_b64encode(x).rstrip(b"=").decode()
_ub = lambda s: base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
_mac = lambda s: _b(hmac.new(settings.SECRET.encode(), s.encode(), hashlib.sha256).digest())
FAILS: dict = {}


def sign(payload: dict, ttl: int) -> str:
    body = _b(json.dumps(dict(payload, exp=int(time.time()) + ttl), separators=(",", ":")).encode())
    return f"{body}.{_mac(body)}"


def unsign(tok: str):
    try:
        body, sig = tok.split(".")
        if not hmac.compare_digest(sig, _mac(body)):
            return None
        p = json.loads(_ub(body))
        return p if p["exp"] > time.time() else None
    except Exception:
        return None


def hash_otp(acc: str, code: str) -> str:
    return hmac.new(settings.SECRET.encode(), f"{acc}:{code}".encode(), hashlib.sha256).hexdigest()


def staff_login(user: str, pw: str) -> dict:
    recent = [t for t in FAILS.get(user, []) if t > time.time() - 300]
    if len(recent) >= 5:
        raise ApiError(429, "Too many failed attempts. Try again in 5 minutes.")
    for row in settings.STAFF_USERS.split(","):
        u, p, role, branch = row.split(":")
        if u == user and hmac.compare_digest(p, pw):
            return {"token": sign({"k": "s", "user": u, "role": role, "branch": branch}, 8 * 3600), "role": role, "branch": branch, "user": u}
    FAILS[user] = recent + [time.time()]
    raise ApiError(401, "Wrong username or password.")


def _bearer(h):
    return h[7:] if h and h.lower().startswith("bearer ") else ""


def customer(authorization: str | None = Header(None)):
    p = unsign(_bearer(authorization))
    if not p or p.get("k") != "c":
        raise ApiError(401, "Please verify your OTP to continue.")
    return p


def staff(*roles):
    def dep(authorization: str | None = Header(None)):
        p = unsign(_bearer(authorization))
        if not p or p.get("k") != "s":
            raise ApiError(401, "Please sign in.")
        if roles and p["role"] not in roles:
            raise ApiError(403, "Your role cannot do this.")
        return p
    return dep
