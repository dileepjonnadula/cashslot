from pathlib import Path

from fastapi import Depends, FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from . import security, service
from .config import settings
from .db import Base, engine, get_db
from .errors import ApiError
from .notify import get_notifier

Base.metadata.create_all(engine)
app = FastAPI(title="Cash Slot plug-in", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=settings.ALLOWED_ORIGINS, allow_methods=["*"], allow_headers=["*"])


@app.exception_handler(ApiError)
async def _api_err(_, e: ApiError): return JSONResponse({"error": e.msg}, status_code=e.status)


@app.exception_handler(RequestValidationError)
async def _val_err(_, e): return JSONResponse({"error": "Please check the details you entered."}, status_code=422)


class OtpReq(BaseModel): account: str
class OtpVerify(BaseModel): account: str; otp: str
class BookReq(BaseModel):
    branch: str; date: str; slot: str; type: str; amount: int = Field(gt=0, lt=10**10); pan: str | None = None
class Login(BaseModel): username: str; password: str
class Reason(BaseModel): reason: str = ""
class CheckIn(BaseModel): token: str; date: str | None = None
class Bio(BaseModel): reference: str
class Done(BaseModel): cbs_ref: str | None = None
class Amt(BaseModel): amount: int = Field(gt=0)
class Close(BaseModel): counted_cash: int = Field(ge=0)


TELLER, MANAGER = security.staff("teller", "manager"), security.staff("manager")

# ---- public / customer ----
@app.get("/api/health")
def health(): return {"ok": True}


@app.get("/api/config")
def config():
    return {"bank": settings.BANK_NAME, "branches": settings.BRANCHES, "today": service.today(), "max_days": settings.MAX_DAYS_AHEAD,
            "pan_deposit_above": settings.PAN_DEPOSIT_ABOVE, "pan_withdraw_atleast": settings.PAN_WITHDRAW_ATLEAST, "dev": settings.DEV_MODE}


@app.get("/api/slots")
def slots(branch: str, date: str, db: Session = Depends(get_db)): return service.slots_view(db, branch, date)
@app.post("/api/otp/request")
def otp_request(r: OtpReq, db: Session = Depends(get_db)): return service.request_otp(db, r.account.strip())
@app.post("/api/otp/verify")
def otp_verify(r: OtpVerify, db: Session = Depends(get_db)): return service.verify_otp(db, r.account.strip(), r.otp.strip())


@app.post("/api/bookings")
def book(r: BookReq, c=Depends(security.customer), db: Session = Depends(get_db)):
    return service.view(service.create_booking(db, c["acc"], r.branch, r.date, r.slot, r.type, r.amount, r.pan))


@app.get("/api/bookings")
def mine(c=Depends(security.customer), db: Session = Depends(get_db)): return service.my_bookings(db, c["acc"])
@app.post("/api/bookings/{bid}/cancel")
def cancel(bid: int, c=Depends(security.customer), db: Session = Depends(get_db)): return service.cancel(db, c["acc"], bid)


# ---- staff ----
@app.post("/api/staff/login")
def login(r: Login): return security.staff_login(r.username.strip(), r.password)
@app.get("/api/staff/bookings")
def s_list(date: str | None = None, s=Depends(TELLER), db: Session = Depends(get_db)): return service.list_bookings(db, s["branch"], date or service.today())
@app.get("/api/staff/cash")
def s_cash(date: str | None = None, s=Depends(TELLER), db: Session = Depends(get_db)): return service.cash_status(db, s["branch"], date or service.today())
@app.post("/api/staff/cash/add")
def s_cash_add(r: Amt, s=Depends(MANAGER), db: Session = Depends(get_db)): return service.add_cash(db, s["branch"], r.amount, s["user"])
@app.post("/api/staff/bookings/{bid}/approve")
def s_approve(bid: int, s=Depends(MANAGER), db: Session = Depends(get_db)): return service.approve(db, bid, s["branch"], s["user"])
@app.post("/api/staff/bookings/{bid}/reject")
def s_reject(bid: int, r: Reason, s=Depends(MANAGER), db: Session = Depends(get_db)): return service.reject(db, bid, s["branch"], s["user"], r.reason)
@app.post("/api/staff/checkin")
def s_checkin(r: CheckIn, s=Depends(TELLER), db: Session = Depends(get_db)): return service.checkin(db, s["branch"], r.token, r.date, s["user"])
@app.post("/api/staff/bookings/{bid}/biometric")
def s_bio(bid: int, r: Bio, s=Depends(TELLER), db: Session = Depends(get_db)): return service.biometric(db, bid, s["branch"], r.reference, s["user"])
@app.post("/api/staff/bookings/{bid}/complete")
def s_complete(bid: int, r: Done, s=Depends(TELLER), db: Session = Depends(get_db)): return service.complete(db, bid, s["branch"], r.cbs_ref, s["user"])
@app.get("/api/staff/report")
def s_report(date: str | None = None, s=Depends(TELLER), db: Session = Depends(get_db)): return service.report(db, s["branch"], date or service.today())
@app.post("/api/staff/close-day")
def s_close(r: Close, s=Depends(MANAGER), db: Session = Depends(get_db)): return service.close_day(db, s["branch"], r.counted_cash, s["user"])


# ---- receipts (unguessable link sent by SMS) ----
@app.get("/r/{ref}/pdf")
def r_pdf(ref: str, db: Session = Depends(get_db)):
    return Response(service.receipt_pdf(service.receipt_data(db, ref)), media_type="application/pdf", headers={"Content-Disposition": "inline; filename=receipt.pdf"})
@app.get("/r/{ref}", response_class=HTMLResponse)
def r_html(ref: str, db: Session = Depends(get_db)): return service.receipt_html(service.receipt_data(db, ref))


if settings.DEV_MODE:
    @app.get("/api/dev/outbox")
    def outbox(): return getattr(get_notifier(), "outbox", [])


STATIC = Path(__file__).parent / "static"
@app.get("/")
def root(): return RedirectResponse("/ui")
@app.get("/ui")
def ui(): return FileResponse(STATIC / "index.html")
