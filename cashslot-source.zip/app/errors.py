class ApiError(Exception):
    def __init__(self, status: int, msg: str):
        self.status, self.msg = status, msg
