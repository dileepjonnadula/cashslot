# Cash Slot: pre-booked cash deposit/withdrawal plug-in for core banking

A standalone service that a CBS vendor (Finacle, TCS BaNCS, Flexcube) or a bank can embed. It books time slots for
counter cash transactions, validates the customer through **one read-only CBS call**, plans branch cash, and
produces receipts and an end-of-day report. **The plug-in never posts to the CBS.** The teller still posts the
transaction in the core system and enters its reference here.

## How it fits
```
Customer app / WhatsApp / kiosk ─┐                       ┌─> CBS account-inquiry API (read-only)
Teller & manager screens ────────┼─> Cash Slot service ──┼─> Bank biometric service (reference only)
(iframe /ui or call REST API)    │   (FastAPI + Postgres)└─> SMS/WhatsApp gateway (webhook)
```

## Run it (demo, 2 minutes)
```
pip install -r requirements.txt
uvicorn app.main:app --port 8000        # open http://localhost:8000/ui
pytest -q                               # 12 tests
```
Demo logins: teller1/teller123, manager1/manager123. Demo accounts and the OTP are shown on screen while `DEV_MODE=1`.
The staff dashboard refreshes branch bookings, cash and report data every 15 seconds while open; use **Refresh now** to update immediately.
Production: copy `.env.example` to `.env` (set `DEV_MODE=0`) and run `docker compose up`.

## Publish a public demo (GitHub + Render)

This project is a FastAPI backend with a web UI, so GitHub Pages alone cannot host it. The included `render.yaml` configures a demo web service on Render. It deliberately uses mock bank integrations and a temporary SQLite database; demo bookings can be erased when the service restarts or redeploys.

1. Install Git for Windows and sign in to GitHub. Create an **empty public repository** named `cashslot` (do not initialize it with a README, license, or `.gitignore`).
2. In PowerShell, from this project folder, run the following commands, replacing `<YOUR-GITHUB-USERNAME>`:

   ```powershell
   git init
   git add .
   git status
   git commit -m "Publish Cash Slot demo"
   git branch -M main
   git remote add origin https://github.com/<YOUR-GITHUB-USERNAME>/cashslot.git
   git push -u origin main
   ```

   Review `git status` before committing. `.gitignore` excludes local environment files, virtual environments, caches, and SQLite databases.
3. In Render, choose **New → Blueprint**, connect the `cashslot` GitHub repository, and deploy. Render reads `render.yaml`; its health check is `/api/health`. After deployment, open the service's public `onrender.com` URL and add `/ui` to view the app.

**Demo only:** the published app enables demo OTP display and includes demo staff credentials (`teller1` / `teller123`, `manager1` / `manager123`) and fake accounts. Anyone with the URL can use it, and demo data is temporary. Do not enter real customer information, connect a real CBS/SMS/biometric service, or use this deployment for banking operations. A production deployment needs a persistent PostgreSQL database and a separate security, privacy, and compliance review.

## What a vendor must implement (3 plug-in points)

| Plug-in point | Interface | Config |
|---|---|---|
| **CBS lookup (required)** | `CBSAdapter.get_account(acc_no) -> Account or None` in `app/adapters/__init__.py` | `CBS_ADAPTER=rest` + `config/cbs_rest.json`, or `CBS_ADAPTER=your.module:YourAdapter` |
| Biometric | `BiometricProvider.verify(acc_no, reference) -> ref or None` in `app/biometric.py` | `BIO_PROVIDER=your.module:Class` |
| Notifications | `Notifier.send(mobile, text, event)` in `app/notify.py` | `NOTIFIER=webhook` + `NOTIFY_WEBHOOK_URL`, or a class |

`Account` fields needed from the CBS: name, status (Active/Frozen/...), available balance (whole rupees), registered mobile, optional PAN, KYC flag.

**REST adapter:** copy `config/cbs_rest.example.json` to `config/cbs_rest.json` and set `base_url`, `account_lookup.path`, the
`map` (dotted paths into the response JSON) and `active_values`. If the CBS uses SOAP, MQ or a database view, write a
~20 line Python adapter class instead. The example mapping is illustrative: Finacle, BaNCS and Flexcube gateways each
have their own inquiry service and field names, which the vendor's integration team must supply.

## Business rules implemented
- OTP to the **CBS-registered mobile** (3 requests per 10 min, 5 tries, 5 min expiry). Frozen or unknown accounts get no OTP and no hint.
- Booking checks: account active, KYC OK, balance for withdrawals, PAN format and match with CBS PAN, slot capacity, max 2 active bookings per account per day, no bookings on a closed day.
- **Cash planning:** confirmed withdrawals reserve cash for their date. A withdrawal above unreserved cash becomes **Pending**; a manager adds cash and approves, and the customer gets an SMS. Large amounts (₹10L and above, configurable) are flagged and can alert a manager.
- Counter: check-in (time window when `ENFORCE_TIME=1`), biometric reference, complete. The account is **re-validated against the CBS at completion**.
- Receipt link by SMS (unguessable URL) in HTML and PDF, without balance.
- End of day: the manager enters the counted cash. The report shows expected vs counted with variance, and unfinished tokens become No-show.
- Hash-chained audit log of every booking, approval, check-in, biometric result, cash change and day close.

## Compliance notes (confirm with the bank's compliance team)
- PAN thresholds are configurable (`PAN_DEPOSIT_ABOVE` = ₹50,000 for deposits, `PAN_WITHDRAW_ATLEAST` = ₹20 lakh for withdrawals). They are defaults, not legal advice. CTR/SFT reporting stays in the bank's existing systems.
- No raw biometric or Aadhaar data is received or stored. Aadhaar authentication must run through the bank's UIDAI-authorised service.
- PAN is stored masked only. Mobile numbers are not stored; they are fetched from the CBS when a message is sent.
- Keep the database and logs inside India.

## Before production
1. `DEV_MODE=0`, a strong `SECRET`, HTTPS in front, restricted `ALLOWED_ORIGINS`.
2. Replace `STAFF_USERS` with the bank's SSO/LDAP (edit `staff_login` in `app/security.py`).
3. Use Postgres and 2+ workers (slot booking uses DB advisory locks on Postgres).
4. Implement and UAT-test the CBS adapter; add a real biometric provider and SMS gateway.
5. Add migrations (Alembic) and monitoring; run VAPT and a security review per bank policy.
6. Keep staff endpoints on the bank network or VPN. The list of upcoming large withdrawals is sensitive.

## API summary
Customer: `POST /api/otp/request`, `POST /api/otp/verify`, `GET /api/slots`, `POST /api/bookings`, `GET /api/bookings`, `POST /api/bookings/{id}/cancel`.
Staff: `POST /api/staff/login`, `GET /api/staff/bookings`, `GET /api/staff/cash`, `POST /api/staff/cash/add`, `POST /api/staff/bookings/{id}/approve|reject|biometric|complete`, `POST /api/staff/checkin`, `GET /api/staff/report`, `POST /api/staff/close-day`.
Public: `GET /r/{ref}` and `/r/{ref}/pdf` (receipts). Interactive API docs at `/docs`.
